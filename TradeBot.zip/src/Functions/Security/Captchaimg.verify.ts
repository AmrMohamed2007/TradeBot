async function VerifyShape(selected:string,correct:string) {
    if(selected == correct) {
        return true;
    }
    else
    return false;
}

export default {VerifyShape}