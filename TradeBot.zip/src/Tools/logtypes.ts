const TypesLog = {
    TransferTerra: 0,
    CardTransfer: 1,
    PremiumBuy: 2


}

export { TypesLog }
