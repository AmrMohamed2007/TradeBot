exports.version = require('../../../package.json').version;
module.exports.GiveawaysManager = require('./src/Manager');
exports.Giveaway = require('./src/Giveaway');